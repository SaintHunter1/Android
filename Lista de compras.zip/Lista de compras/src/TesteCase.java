import junit.framework.TestCase;


public class TesteCase extends TestCase {

	
    public void listar() throws Exception {  
    	
        try {  

        
        } catch (Exception e) {   
        	
        }  
    }  

    

}
