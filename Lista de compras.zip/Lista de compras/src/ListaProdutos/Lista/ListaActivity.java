package ListaProduto.ListaProdutos;

import android.app.Activity;
import android.os.Bundle;

public class ListaActivity extends Activity {

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
}