
public interface InterfaceClass {

public interface

}
