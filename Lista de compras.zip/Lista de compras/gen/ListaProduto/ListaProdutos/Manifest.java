package ListaProduto.ListaProdutos;
public final class Manifest {
}