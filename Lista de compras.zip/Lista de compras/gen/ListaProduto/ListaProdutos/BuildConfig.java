package ListaProduto.ListaProdutos;
public final class BuildConfig {
  public final static boolean DEBUG = Boolean.parseBoolean(null);
}